package icycle.com.project_icycle;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Browse_Groups_Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse__groups__main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageButton map = (ImageButton) findViewById(R.id.buttonMap);
        ImageButton group = (ImageButton) findViewById(R.id.buttonGroup);
        ImageButton health = (ImageButton) findViewById(R.id.buttonHealth);
        ImageButton profile = (ImageButton) findViewById(R.id.buttonProfile);
        Button mygroup = (Button) findViewById(R.id.mygroup);
        Button north = (Button) findViewById(R.id.north);
        Button south = (Button) findViewById(R.id.south);
        Button east = (Button) findViewById(R.id.east);
        Button west = (Button) findViewById(R.id.west);

        mygroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, browse_groups.class);
                startActivity(intent);
            }
        });

        north.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, browse_groups.class);
                startActivity(intent);
            }
        });

        south.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, browse_groups.class);
                startActivity(intent);
            }
        });

        east.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, browse_groups.class);
                startActivity(intent);
            }
        });

        west.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, browse_groups.class);
                startActivity(intent);
            }
        });

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, Direction.class);
                startActivity(intent);
            }
        });

        group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, Browse_Groups_Main.class);
                startActivity(intent);
            }
        });

        health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, Health_Connect_Device.class);
                startActivity(intent);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Browse_Groups_Main.this, Profile.class);
                startActivity(intent);
            }
        });

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
    }

}
