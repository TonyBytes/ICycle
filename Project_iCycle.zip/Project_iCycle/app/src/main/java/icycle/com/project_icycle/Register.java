package icycle.com.project_icycle;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends Activity {

    EditText ET_USERNAME, ET_USER_PASS, ET_USER_REPASS;
    String username, password, repassword;
    String name = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        ET_USERNAME = (EditText)findViewById(R.id.register_username);
        ET_USER_PASS = (EditText)findViewById(R.id.register_password);
        ET_USER_REPASS = (EditText)findViewById(R.id.register_retype_password);
    }

public void userReg(View view){

    username = ET_USERNAME.getText().toString();
    password = ET_USER_PASS.getText().toString();
    repassword = ET_USER_REPASS.getText().toString();
 //   if(password.equals(repassword)) {
        String method = "register";
        DB_connect db_connect = new DB_connect(this);
        db_connect.execute(method,name , username, password);
        finish();
   // }else{
        //Toast.makeText(this,"Please retype the correct password",Toast.LENGTH_LONG).show();
    //}



}

}
